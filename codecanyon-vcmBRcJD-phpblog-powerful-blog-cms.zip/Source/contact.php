<?php
include "core.php";
head();
?>
    <div class="container">
        <div class="row">
            <div class="col-md-8">

            <section class="alignleft col-lg-12">
                <div class="title-divider">
                    <h3><i class="fas fa-envelope"></i> Contact</h3>
                    <div class="divider-arrow"></div>
                </div>
                <div class="block-grey">
                    <div class="block-light wrapper">
                            <h3>Social Profiles</h3><br />
<ul>
<?php
$run  = mysqli_query($connect, "SELECT * FROM `settings`");
$site = mysqli_fetch_assoc($run);
?>
                    <li><a href="mailto:<?php
echo $site['email'];
?>" target="_blank"><strong><i class="fa fa-envelope fa-2x"></i><span>&nbsp; <?php
echo $site['email'];
?></span></strong></a></li>
<?php
if ($site['facebook'] != '') {
?>
                    <li><a href="<?php
    echo $site['facebook'];
?>" target="_blank"><strong><i class="fab fa-facebook-square fa-2x"></i>&nbsp; Facebook</strong></a></li>
<?php
}
if ($site['instagram'] != '') {
?>
					<li><a href="<?php
    echo $site['instagram'];
?>" target="_blank"><strong><i class="fab fa-instagram fa-2x"></i>&nbsp; Instagram</strong></a></li>
<?php
}
if ($site['twitter'] != '') {
?>
					<li><a href="<?php
    echo $site['twitter'];
?>" target="_blank"><strong><i class="fab fa-twitter-square fa-2x"></i>&nbsp; Twitter</strong></a></li>
<?php
}
if ($site['youtube'] != '') {
?>	
					<li><a href="<?php
    echo $site['youtube'];
?>" target="_blank"><strong><i class="fab fa-youtube-square fa-2x"></i>&nbsp; YouTube</strong></a></li>
<?php
}
?>	    
			</ul>
                            <br /><hr>
                        <h3>Leave Your Message</h3>
						<br />
<?php
if (isset($_POST['send'])) {
    $name    = $_POST['name'];
    $email   = $_POST['email'];
    $content = $_POST['text'];
    
    $date = date('d F Y');
    $time = date('H:i');
	
	$captcha = '';
    
    if (isset($_POST['g-recaptcha-response'])) {
        $captcha = $_POST['g-recaptcha-response'];
    }
    if ($captcha) {
        $url          = 'https://www.google.com/recaptcha/api/siteverify?secret=' . urlencode($row['gcaptcha_secretkey']) . '&response=' . urlencode($captcha);
        $response     = file_get_contents($url);
        $responseKeys = json_decode($response, true);
        if ($responseKeys["success"]) {
            
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                echo '<div class="alert alert-danger">The entered E-Mail Address is invalid</div>';
            } else {
                $query = mysqli_query($connect, "INSERT INTO messages (name, email, content, date, time) VALUES('$name','$email','$content','$date','$time')");
                echo '<div class="alert alert-success">Your message has been sent successfully</div>';
            }
        }
    }
}
?>
                        <form id="cform" method="post" action="">
                                    <label for="name"><i class="fa fa-user"></i> Your Name:</label>
                                    <input type="text" name="name" id="name" value="" class="form-control" required />
                                    <br />
									
                                    <label for="email"><i class="fa fa-envelope"></i> Your E-Mail Address:</label>
                                    <input type="email" name="email" id="email" value="" class="form-control" required />
                                    <br />

                                    <label for="input-message"><i class="far fa-file-alt"></i> Your Message:</label>
                                    <textarea name="text" id="input-message" rows="10" class="form-control" required></textarea>

                                    <br /><center><div class="g-recaptcha" data-sitekey="<?php
echo $row['gcaptcha_sitekey'];
?>"></div></center><br />

									<br />
                                    <input type="submit" name="send" class="btn btn-primary btn-block" value="Send" />
                        </form><br />
                    </div>
			    </div>
			</section>

			</div>
<?php
sidebar();
footer();
?>