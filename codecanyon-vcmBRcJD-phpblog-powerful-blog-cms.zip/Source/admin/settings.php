<?php
include "header.php";

if (isset($_POST['save'])) {
    $sitename           = $_POST['sitename'];
    $description        = $_POST['description'];
    $keywords           = $_POST['keywords'];
    $email              = $_POST['email'];
    $gcaptcha_sitekey   = $_POST['gcaptcha-sitekey'];
    $gcaptcha_secretkey = $_POST['gcaptcha-secretkey'];
    $facebook           = $_POST['facebook'];
    $instagram          = $_POST['instagram'];
    $twitter            = $_POST['twitter'];
    $youtube            = $_POST['youtube'];
    $comments           = $_POST['comments'];
    $theme              = $_POST['theme'];
    $edit               = "UPDATE settings SET sitename='$sitename', description='$description', keywords='$keywords', email='$email', gcaptcha_sitekey='$gcaptcha_sitekey', gcaptcha_secretkey='$gcaptcha_secretkey', facebook='$facebook', instagram='$instagram', twitter='$twitter', youtube='$youtube', comments='$comments', theme='$theme'";
    $sql                = mysqli_query($connect, $edit);
}
?>

	<div class="col-md-9">
      <div>
        <ol class="breadcrumb">
          <li><a href="dashboard.php">Home</a></li>
          <li class="active">Settings</li>
        </ol>
      </div>

      <div class="row">
         
        <div class="col-md-12 column">
            <div class="box">
              <h4 class="box-header round-top">Settings</h4>         
              <div class="box-container-toggle">
                  <div class="box-content">
<?php
$sql    = "SELECT * FROM settings";
$result = mysqli_query($connect, $sql);
while ($s = mysqli_fetch_assoc($result)) {
?>
                                <form action="" method="post">
								<p>
									<label>Site Name</label>
									<input class="form-control" name="sitename" value="<?php
    echo $s['sitename'];
?>" type="text" required>
								</p>
								<p>
									<label>Description</label>
									<textarea class="form-control" name="description" required><?php
    echo $s['description'];
?></textarea>
								</p>
								<p>
									<label>Keywords</label>
									<input class="form-control" name="keywords" value="<?php
    echo $s['keywords'];
?>" type="text" required>
								</p>
								<p>
									<label>Website's E-Mail Address</label>
									<input class="form-control" name="email" type="email" value="<?php
    echo $s['email'];
?>" type="email" required>
								</p>
								<p>
									<label>reCAPTCHA v2 Site Key:</label>
									<input class="form-control" name="gcaptcha-sitekey" value="<?php
    echo $s['gcaptcha_sitekey'];
?>" type="text" required>
								</p>
								<p>
									<label>reCAPTCHA v2 Secret Key:</label>
									<input class="form-control" name="gcaptcha-secretkey" value="<?php
    echo $s['gcaptcha_secretkey'];
?>" type="text" required>
								</p>
								<p>
									<label>Facebook Profile</label>
									<input class="form-control" name="facebook" type="url" value="<?php
    echo $s['facebook'];
?>" type="text">
								</p>
								<p>
									<label>Instagram Profile</label>
									<input class="form-control" name="instagram" type="url" value="<?php
    echo $s['instagram'];
?>" type="text">
								</p>
								<p>
									<label>Twitter Profile</label>
									<input class="form-control" name="twitter" type="url" value="<?php
    echo $s['twitter'];
?>" type="text">
								</p>
								<p>
									<label>Youtube Profile</label>
									<input class="form-control" name="youtube" type="url" value="<?php
    echo $s['youtube'];
?>" type="text">
								</p>
								<p><label>Comments Section</label><br />
									<select name="comments" class="form-control" required>
									    <option value="guests" <?php
    if ($s['comments'] == "guests") {
        echo 'selected';
    }
?>>Registration not required</option>
										<option value="registered" <?php
    if ($s['comments'] == "registered") {
        echo 'selected';
    }
?>>Registration required</option>
                                    </select>
								</p>
								<p><label>Theme</label><br />
									<select name="theme" class="form-control" required>
									    <option value="flatly" <?php
    if ($s['theme'] == "flatly") {
        echo 'selected';
    }
?>>Flatly</option>
										<option value="cerulean" <?php
    if ($s['theme'] == "cerulean") {
        echo 'selected';
    }
?>>Cerulean</option>
										<option value="cosmo" <?php
    if ($s['theme'] == "cosmo") {
        echo 'selected';
    }
?>>Cosmo</option>
										<option value="journal" <?php
    if ($s['theme'] == "journal") {
        echo 'selected';
    }
?>>Journal</option>
										<option value="lumen" <?php
    if ($s['theme'] == "lumen") {
        echo 'selected';
    }
?>>Lumen</option>
										<option value="paper" <?php
    if ($s['theme'] == "paper") {
        echo 'selected';
    }
?>>Paper</option>
										<option value="readable" <?php
    if ($s['theme'] == "readable") {
        echo 'selected';
    }
?>>Readable</option>
										<option value="sandstone" <?php
    if ($s['theme'] == "sandstone") {
        echo 'selected';
    }
?>>Sandstone</option>
										<option value="simplex" <?php
    if ($s['theme'] == "simplex") {
        echo 'selected';
    }
?>>Simplex</option>
										<option value="spacelab" <?php
    if ($s['theme'] == "spacelab") {
        echo 'selected';
    }
?>>Spacelab</option>
										<option value="united" <?php
    if ($s['theme'] == "united") {
        echo 'selected';
    }
?>>United</option>
										<option value="yeti" <?php
    if ($s['theme'] == "yeti") {
        echo 'selected';
    }
?>>Yeti</option>
                                    </select>
								</p>
								<div class="form-actions">
                                    <input type="submit" name="save" class="btn btn-primary btn-block" value="Save Changes" />
                                </div>
								</form>

<?php
}
?>                             
                  </div>
              </div>
            </div>
        </div>
      </div>

    </div>
  </div>

<?php
include "footer.php";
?>