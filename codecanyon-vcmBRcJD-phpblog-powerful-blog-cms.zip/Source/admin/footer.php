  <footer class="footer">
      <div class="container">
   <p class="text-muted">&copy; <?php
echo date("Y");
?> phpBlog</p>
      </div>
  </footer>
</div>

    <!-- Bootstrap --> 
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>  
    
    <!--DataTables-->
    <script src="https://cdn.datatables.net/v/bs/dt-1.10.20/r-2.2.3/datatables.min.js"></script>

  </body>
</html>