<?php
include "core.php";
head();

$error = 0;
?>
    <div class="container">
        <div class="row">
            <div class="col-md-8">

                    <section class="alignleft col-md-12">
                        <div class="title-divider">
                            <h3><i class="fas fa-sign-in-alt"></i> Sign In</h3>
                            <div class="divider-arrow"></div>
                        </div>
                        <div class="block-grey">
                            <div class="block-light wrap15">
                                <div class="row">
									<div class="col-md-6">
										<h4><i class="fas fa-user-plus"></i> Registration</h4><hr />
                <?php
if (isset($_POST['register'])) {
    $username = $_POST['username'];
    $password = hash('sha256', $_POST['password']);
    $email    = $_POST['email'];
    $captcha  = '';
    if (isset($_POST['g-recaptcha-response'])) {
        $captcha = $_POST['g-recaptcha-response'];
    }
    if ($captcha) {
        $url          = 'https://www.google.com/recaptcha/api/siteverify?secret=' . urlencode($row['gcaptcha_secretkey']) . '&response=' . urlencode($captcha);
        $response     = file_get_contents($url);
        $responseKeys = json_decode($response, true);
        if ($responseKeys["success"]) {
            
            $sql = mysqli_query($connect, "SELECT username FROM `users` WHERE username='$username'");
            if (mysqli_num_rows($sql) > 0) {
                echo '<br /><div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> This username is taken</div>';
            } else {
                
                $sql2 = mysqli_query($connect, "SELECT email FROM `users` WHERE email='$email'");
                if (mysqli_num_rows($sql2) > 0) {
                    echo '<br /><div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> This E-Mail Address is taken</div>';
                } else {
                    $insert  = mysqli_query($connect, "INSERT INTO `users` (`username`, `password`, `email`) VALUES ('$username', '$password', '$email')");
                    $insert2 = mysqli_query($connect, "INSERT INTO `newsletter` (`email`) VALUES ('$email')");
                    
                    $subject = 'Welcome at ' . $row['sitename'] . '';
                    $message = '
                                    <center>
                					<a href="' . $site_url . '" title="Visit ' . $row['sitename'] . '" target="_blank">
                					<h1>' . $row['sitename'] . '</h1>
                					</a><br />

                					<h2>You have successfully registered at ' . $row['sitename'] . '</h2><br /><br />

                					<b>Registration details:</b><br />
                					Username: ' . $username . '<b></b><br />
                					</center>
                				    ';
                    $headers = 'MIME-Version: 1.0' . "\r\n";
                    $headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";
                    $headers .= 'To: ' . $email . ' <' . $email . '>' . "\r\n";
                    $headers .= 'From: ' . $row['email'] . ' <' . $row['email'] . '>' . "\r\n";
                    @mail($email, $subject, $message, $headers);
                    
                    $_SESSION['sec-username'] = $username;
                    echo '<meta http-equiv="refresh" content="0;url=profile.php">';
                }
            }
        }
    }
}
?>
<form action="" method="post">
            <div class="form-group has-feedback">
                <input type="username" name="username" class="form-control" placeholder="Username" required>
                <span class="glyphicon glyphicon-user form-control-feedback"></span>
            </div>
			<div class="form-group has-feedback">
                <input type="email" name="email" class="form-control" placeholder="E-Mail Address" required>
				<span class="glyphicon glyphicon-envelope form-control-feedback"></span>
            </div>
            <div class="form-group has-feedback">
                <input type="password" name="password" class="form-control" placeholder="Password" required>
				<span class="glyphicon glyphicon-lock form-control-feedback"></span>
            </div>
			<center><div class="g-recaptcha" data-sitekey="<?php
echo $row['gcaptcha_sitekey'];
?>"></div></center><br />
            <div class="row">
                <div class="col-xs-12">
                    <button type="submit" name="register" class="btn btn-primary btn-block btn-flat"><i class="fas fa-sign-in-alt"></i>
&nbsp;Sign Up</button>
                </div>
            </div>
        </form> 
									</div>
									<div class="col-md-6">
										<h4><i class="fas fa-sign-in-alt"></i> Sign In</h4><hr />
<?php
if (isset($_POST['signin'])) {
    $username = mysqli_real_escape_string($connect, $_POST['username']);
    $password = hash('sha256', $_POST['password']);
    $check    = mysqli_query($connect, "SELECT username, password FROM `users` WHERE `username`='$username' AND password='$password'");
    if (mysqli_num_rows($check) > 0) {
        $_SESSION['sec-username'] = $username;
        echo '<meta http-equiv="refresh" content="0;url=profile.php">';
    } else {
        echo '<br />
		<div class="alert alert-danger">
              <i class="fas fa-exclamation-circle"></i> The entered <strong>Username</strong> or <strong>Password</strong> is incorrect.
        </div>';
        $error = 1;
    }
}
?> 
<form action="" method="post">
            <div class="form-group has-feedback <?php
if ($error == 1) {
    echo 'has-error';
}
?>">
                <input type="username" name="username" class="form-control" placeholder="Username" <?php
if ($error == 1) {
    echo 'autofocus';
}
?> required>
                <span class="glyphicon glyphicon-user form-control-feedback"></span>
            </div>
            <div class="form-group has-feedback">
                <input type="password" name="password" class="form-control" placeholder="Password" required>
				<span class="glyphicon glyphicon-lock form-control-feedback"></span>
            </div>
            <div class="row">
                <div class="col-xs-12">
                    <button type="submit" name="signin" class="btn btn-primary btn-block btn-flat"><i class="fas fa-sign-in-alt"></i>
&nbsp;Sign In</button>
                </div>
            </div>
        </form> 
									</div>
								</div>								
                            </div>
                        </div>
            </section>
					
			</div>
<?php
sidebar();
footer();
?>