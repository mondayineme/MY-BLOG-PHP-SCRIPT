<?php
include "core.php";
head();
?>
    <div class="container">
        <div class="row">
            <div class="col-md-8">

            <section class="alignleft col-lg-12">
                <div class="title-divider">
                    <h3><i class="fas fa-envelope"></i> Unsubscribe</h3>
                    <div class="divider-arrow"></div>
                </div>
                <div class="block-grey">
                    <div class="block-light wrapper">
<?php
$email = $_GET['email'];
if (empty($email)) {
    echo '<meta http-equiv="refresh" content="0;url=index.php">';
    exit;
}

$querych = mysqli_query($connect, "SELECT * FROM `newsletter` WHERE email='$email' LIMIT 1");
if (mysqli_num_rows($querych) == 0) {
    echo '<meta http-equiv="refresh" content="0; url=index.php">';
    exit;
}

$query = mysqli_query($connect, "DELETE FROM `newsletter` WHERE email='$email'");
echo '<center><div class="alert alert-primary">You were unsubscribed successfully</div></center>';

?>
                    </div>
			    </div>
			</section>

			</div>
<?php
sidebar();
footer();
?>