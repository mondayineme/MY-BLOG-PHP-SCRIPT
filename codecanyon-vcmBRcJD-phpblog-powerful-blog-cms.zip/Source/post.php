<?php
include "core.php";
head();
?>
    <div class="container">
        <div class="row">
            <div class="col-md-8">

                    <section class="alignleft col-md-12">
<?php
$id = (int) $_GET['id'];

if (empty($id)) {
    echo '<meta http-equiv="refresh" content="0; url=blog.php">';
    exit;
}

$runq = mysqli_query($connect, "SELECT * FROM `posts` WHERE id='$id'");
if (mysqli_num_rows($runq) == 0) {
    echo '<meta http-equiv="refresh" content="0; url=blog.php">';
    exit;
}

mysqli_query($connect, "UPDATE `posts` SET views = views + 1 WHERE active='Yes' and id='$id'");
$row         = mysqli_fetch_assoc($runq);
$post_id     = $row['id'];
$runq3       = mysqli_query($connect, "SELECT * FROM `comments` WHERE post_id='$post_id' AND approved='Yes'");
$uNum        = mysqli_num_rows($runq3);
$category_id = $row['category_id'];
$runq4       = mysqli_query($connect, "SELECT * FROM `categories` WHERE id='$category_id'");
$cat         = mysqli_fetch_array($runq4);
echo '
                    <article class="blog-post">
                        <div class="block-grey">
                            <div class="block-light">
							';
if ($row['image'] != '') {
    echo '
                                <div class="wrapper-img">
                                    <img src="' . $row['image'] . '" width="100%" height="260" alt="' . $row['title'] . '"/>
                                </div>';
}
echo '
                                <div class="wrapper">
                                    <h2 class="post-title">' . $row['title'] . '</h2><hr />
                                    ' . html_entity_decode($row['content']) . '
									<hr>
                                    <p>
                                        <i class="fa fa-calendar"></i> Date: ' . $row['date'] . '&nbsp;&nbsp;&nbsp;
										<i class="fa fa-comments"></i> Comments: <a href="#comments">' . $uNum . '</a>&nbsp;&nbsp;&nbsp;
										<i class="fas fa-list"></i> Category: <a href="category.php?id=' . $cat['id'] . '">' . $cat['category'] . '</a>
                                    </p>
                                    <hr>

                                    <div class="title-divider" id="comments">
                                        <h3><i class="fa fa-comments"></i> Comments - ' . $uNum . '</h3>
                                        <div class="divider-arrow"></div>
                                    </div>
';
?>

<?php
$q     = mysqli_query($connect, "SELECT * FROM comments WHERE post_id='$row[id]' AND approved='Yes' ORDER BY id DESC");
$count = mysqli_num_rows($q);
if ($count <= 0) {
    echo '<div class="alert alert-info">There are no comments yet</div>';
} else {
    while ($comment = mysqli_fetch_array($q)) {
        $aauthor = $comment['user_id'];
        
        if ($comment['guest'] == 'Yes') {
            $aavatar = 'assets/img/avatar.png';
        } else {
            
            $querych = mysqli_query($connect, "SELECT * FROM `users` WHERE id='$aauthor' LIMIT 1");
            if (mysqli_num_rows($querych) > 0) {
                $rowch = mysqli_fetch_assoc($querych);
                
                $aavatar = $rowch['avatar'];
                $aauthor = $rowch['username'];
            }
        }
        
        echo '
	    <article class="row">
            <div class="col-md-2">
              <figure class="thumbnail">
                <img class="img-responsive" src="' . $aavatar . '" alt="' . $aauthor . '" />
              </figure>
            </div>
            <div class="col-md-10">
              <div class="panel panel-default">
                <div class="panel-body">
                  <header class="text-left">
                    <div class="comment-user"><i class="fa fa-user"></i> ' . $aauthor . '</div>
                    <time class="comment-date"><i class="fa fa-calendar-alt"></i> ' . $comment['date'] . ' at ' . $comment['time'] . '</time>
                  </header><hr />
                  <div class="comment-post">
                    <p>' . emoticons($comment['comment']) . ' </p>
                  </div>
                </div>
              </div>
            </div>
		</article>
	';
    }
}
?>                                  <br />
									
                                    <div class="title-divider">
                                        <h3>Leave A Comment</h3>
                                        <div class="divider-arrow"></div>
                                    </div>

<?php
$guest = 'No';

$queryst = mysqli_query($connect, "SELECT * FROM `settings` LIMIT 1");
$rowst   = mysqli_fetch_assoc($queryst);
if ($logged == 'No' AND $rowst['comments'] == 'guests') {
    $cancomment = 'Yes';
} else {
    $cancomment = 'No';
}
if ($logged == 'Yes') {
    $cancomment = 'Yes';
}

if ($cancomment == 'Yes') {
?>
                                    <form action="post.php?id=<?php
    echo $id;
?>" method="post">
<?php
    if ($logged == 'No') {
        $guest = 'Yes';
?>
                                                <label for="name"><i class="fa fa-user"></i> Your Name:</label>
                                                <input type="text" name="author" value="" class="form-control" required />
                                                <br />
<?php
    }
?>
                                                <label for="input-message"><i class="fa fa-comment"></i> Comment:</label>
                                                <textarea name="message" rows="5" class="form-control" required></textarea>
                                                <br />
<?php
    if ($logged == 'No') {
        $guest = 'Yes';
?>
												<center><div class="g-recaptcha" data-sitekey="<?php
        echo $rowst['gcaptcha_sitekey'];
?>"></div></center><br />
<?php
    }
?>
                                                <input type="submit" name="post" class="btn btn-primary btn-block" value="Post" />
                                            </div>
                                        </div>
                                    </form>
<?php
} else {
    echo '<div class="alert alert-info">Please <strong><a href="login.php"><i class="fas fa-sign-in-alt"></i> Sign In</a></strong> to be able to post a comment</div>';
}

if ($cancomment == 'Yes') {
    if (isset($_POST['post'])) {
        
        $authname_problem = 'No';
        $date             = date('d F Y');
        $time             = date('H:i');
        
		$captcha = '';
		
        $comment = $_POST['message'];
        if ($logged == 'No') {
            $author = $_POST['author'];
            
            $bot = 'Yes';
            if (isset($_POST['g-recaptcha-response'])) {
                $captcha = $_POST['g-recaptcha-response'];
            }
            if ($captcha) {
                $url          = 'https://www.google.com/recaptcha/api/siteverify?secret=' . urlencode($rowst['gcaptcha_secretkey']) . '&response=' . urlencode($captcha);
                $response     = file_get_contents($url);
                $responseKeys = json_decode($response, true);
                if ($responseKeys["success"]) {
                    $bot = 'No';
                }
            }
            
            if (strlen($author) < 1) {
                $authname_problem = 'Yes';
                echo '<div class="alert alert-warning">Your name is too short</div>';
            }
        } else {
            $bot    = 'No';
            $author = $rowu['id'];
        }
        
        if (strlen($comment) < 1) {
            echo '<div class="alert alert-danger">Your comment is too short</div>';
        } else {
            if ($authname_problem == 'No' AND $bot == 'No') {
                $runq = mysqli_query($connect, "INSERT INTO `comments` (`post_id`, `comment`, `user_id`, `date`, `time`, `guest`) VALUES ('$row[id]', '$comment', '$author', '$date', '$time', '$guest')");
                echo '<div class="alert alert-success">Your comment has been successfully posted</div>';
                echo '<meta http-equiv="refresh" content="0;url=post.php?id=' . $row['id'] . '#comments">';
            }
        }
    }
}
?>
                    </article>
            </section>

			</div>
<?php
sidebar();
footer();
?>